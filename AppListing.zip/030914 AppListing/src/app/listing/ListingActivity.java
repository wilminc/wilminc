/* 
 * 
 * 
 * 
 * ******************IMPORTANT********************
 * Insert your apps through private void addApps()
 * 
 * All of these app DO NOT belong to me. 
 * They are solely for demonstration purposes. 
 * ******************IMPORTANT********************
 * 
 */
package app.listing;

import java.util.ArrayList;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ListingActivity extends Activity implements OnItemClickListener{

	//User Interface
	ListView appView;
	
	//Information holders
	ArrayList<AppItem> list = new ArrayList<AppItem>();
	Uri link;
	Intent action;
	
	private void addApps(){
/*		
 		//How to add new Apps onto the list:
  		list.add(new AppItem(
			Id of the App's Picture,
			Name of the App,
			Description of the App,
			Link to the App on Google Play)
			//NOTE: REPLACE HTTPS:// WITH MARKET://, THEN CUT OUT THE REST OF THE LINK UNTIL IT GETS TO details?id...
			
		);
*/		
        //My own item:
		//Chrome Browser
		list.add(new AppItem(
		        R.drawable.ic_action_search,  // I don't have an image, lets use this
				"Goolge Chrome",
				"The best internet browser you can ever experience",
		        "market://details?id=com.android.chrome"));

        //Angry Birds
		list.add(new AppItem(
				R.drawable.angrybirds,
        		"Flappy Birds",
        		"A fun, interactive physics game suitable for all ages",
        		"market://details?id=com.rovio.angrybirds&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5yb3Zpby5hbmdyeWJpcmRzIl0.")
		);
		
		//Cut the Rope Free
        list.add(new AppItem(
        		R.drawable.cuttheropefree,
        		"Cut the Rope FREE",
        		"A unique puzzle involving thought and timing",
        		"market://details?id=com.zeptolab.ctr.ads&feature=nav_result#?t=W251bGwsMSwyLDNd")
        );
        
        //YouTube
        list.add(new AppItem(
        		R.drawable.youtube,
        		"YouTube",
        		"Watch videos online published by the people, for the people",
        		"market://details?id=com.google.android.youtube&feature=search_result#?t=W251bGwsMSwxLDEsImNvbS5nb29nbGUuYW5kcm9pZC55b3V0dWJlIl0.")
        );
        
        //Puzzle Warriorz
        list.add(new AppItem(
        		R.drawable.puzzle_warriorz,
        		"Puzzle Warriorz",
        		"Play this \"innovative, RPG game \" that's been critically acclaimed on several sites!",
        		"market://details?id=com.org.puzzlewarriorz")
        );
        
        //Lookout Security
        list.add(new AppItem(
        		R.drawable.lookout,
        		"Lookout Security",
        		"Make your mobile device more secure with this app!",
        		"market://details?id=com.lookout")
        );
        
        //Clash of Clans
        list.add(new AppItem(
        		R.drawable.clash_clans,
        		"Clash of the Clans",
        		"Multiplayer strategy game that will keep you hooked forever",
        		"market://details?id=com.supercell.clashofclans")
        );
        
        //Facebook
        list.add(new AppItem(
        		R.drawable.facebook,
        		"Facebook",
        		"Social Media site that connects you with your friends",
        		"market://details?id=com.facebook.katana")
        );
        
        //Candy Crush
        list.add(new AppItem(
        		R.drawable.candy_crush,
        		"Sugar Rush",
        		"Never look up from your phone ever again",
        		"market://details?id=com.king.candycrushsaga")
        );
        
        //Instagram
        list.add(new AppItem(
        		R.drawable.instagram,
        		"Instagram",
        		"Take pictures. Lots of them. Then share them with this app",
        		"market://details?id=com.instagram.android")
        );
        
        //Temple Run 2
        list.add(new AppItem(
        		R.drawable.temple_run,
        		"Temple Run 2",
        		"Play the sequal to the addicting running game that inspired several copycats and spinoffs",
        		"market://details?id=com.imangi.templerun2")
        );
	}
    
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_screen);
        
        appView = (ListView)findViewById(R.id.listListView);
        
        addApps();
        
        appView.setAdapter(new AppItemAdapter(this,R.layout.app_item,list));
        appView.setOnItemClickListener(this);
        	
    }

	public void onItemClick(AdapterView<?> parent, View item, int position, long id) {
		// TODO Auto-generated method stub
		
		action = new Intent();
		action.setAction(Intent.ACTION_VIEW);
		action.addCategory(Intent.CATEGORY_BROWSABLE);
		link = Uri.parse(list.get(position).getAppLink());
		action.setData(link);
		startActivity(action);
			
	}

    
}

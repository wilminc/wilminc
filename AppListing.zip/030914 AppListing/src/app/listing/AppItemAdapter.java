package app.listing;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class AppItemAdapter extends ArrayAdapter<AppItem>{

	//Contains the id of xml layout for an item.
	private int itemLayout;
	
	//Constructor - How any AppItemAdapter will be initialized
	public AppItemAdapter(Context context, int itemLayoutId,
			ArrayList<AppItem> apps) {
		super(context, itemLayoutId, apps);
		itemLayout = itemLayoutId;
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// 
		View v = convertView;
		
		if(v == null){
			LayoutInflater li = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = li.inflate(itemLayout, null);
		}
		AppItem currentItem = getItem(position);
		TextView appName = (TextView) v.findViewById(R.id.appName);
		TextView appDesc = (TextView) v.findViewById(R.id.appDescript);
		ImageView appPic = (ImageView) v.findViewById(R.id.appPicture);
		
		appName.setText(currentItem.getAppName());
		appDesc.setText(currentItem.getAppDescript());
		appPic.setImageResource(currentItem.getAppPicture());	
		
		return v;
	}
}

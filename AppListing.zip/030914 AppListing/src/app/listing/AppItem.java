package app.listing;

public class AppItem {
	//Id of picture
	private int appPicture;
	
	//App Name
	private String appName;
	
	//App Description
	private String appDescript;
	
	//App Uri
	private String appUri;
	
	public AppItem(){
		setAppPicture(-1);
		setAppName(null);
		setAppDescript(null);
		setAppLink(null);
	}
	
	public AppItem(int picId, String appName, String appDescription, String appUri){
		setAppPicture(picId);
		this.setAppName(appName);
		setAppDescript(appDescription);
		this.setAppLink(appUri);
	}

	/**
	 * @return the appPicture
	 */
	public int getAppPicture() {
		return appPicture;
	}

	/**
	 * @param appPicture the appPicture to set
	 */
	public void setAppPicture(int appPicture) {
		this.appPicture = appPicture;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * @return the appDescript
	 */
	public String getAppDescript() {
		return appDescript;
	}

	/**
	 * @param appDescript the appDescript to set
	 */
	public void setAppDescript(String appDescript) {
		this.appDescript = appDescript;
	}

	/**
	 * @return the appUri
	 */
	public String getAppLink() {
		return appUri;
	}

	/**
	 * @param appUri the appUri to set
	 */
	public void setAppLink(String appUri) {
		this.appUri = appUri;
	}
}
